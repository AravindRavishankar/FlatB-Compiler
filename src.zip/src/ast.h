#ifndef _AST_H
#define _AST_H
#include<bits/stdc++.h>
using namespace std;
class visitor{
	public:
		virtual void go(AstNode* node) = 0;
		virtual void go(AstProgram* node) = 0;
		virtual void go(AstEmptyD* node) = 0; 
		virtual void go(AstEmptyC* node) = 0;
		virtual void go(AstIdentifier* node) = 0;
		virtual void go(AstCStatement* node) = 0;
		virtual void go(AstAssignment* node) = 0;
		virtual void go(AstPrintCStatement* node) = 0;
		virtual void go(AstPrintVals* node) = 0;
		virtual void go(AstForLoop* node) = 0;
		virtual void go(AstIfElse* node) = 0;
		virtual void go(AstWhileLoop* node) = 0;
		virtual void go(AstLabel* node) = 0;
		virtual void go(AstReading* node) = 0;
		virtual int go(AstExp* node) = 0;
		virtual int go(AstBinaryExp* node) = 0;
		virtual int go(AstBoolExp* node) = 0;
		virtual int go(AstBinaryExp* node) = 0;
		virtual int go(AstTerm* node) = 0;
		virtual void go(AstIdentifier* node) = 0;
};
enum BinaryOperator
{
	PLUS,
	MINUS,
	PROD,
	DIV
		
};
enum BooleanOperator
{
	GT,
	LT,
	GE,
	LE,
	NEQ,
	EQEQ
};
class AstNode{
	public:
		virtual void visit(visitor* _visitor)=0;
};
class AstTerm;
class AstIdentifier;
class AstNumber;
class AstExp;
class AstBoolExp;
class AstBinaryExp;
class AstReading;
class AstGoToo;
class AstLabel;
class AstIfElse;
class AstProgram;
class AstEmptyC;
class AstCstatement;
class AstCstatement;
class AstAssignment;
class AstPrinting;
class AstExpression;
class AstPrintvals;
class AstForLoop;
class AstWhileLoop;
class AstLabel;
class AstReading;
class AstPrintvals;

class AstProgram : public AstNode{
	
	public : 
		AstEmptyD *emptyd;
		AstEmptyC *emptyc;
 		ASTProgram(ASTEmptyD *emptyd, ASTEmptyC *emptyc) 		  
		{
			this->emptyd = emptyd;
			this->emptyc = emptyc;
		}
		virtual void visit(visitor* _visitor) override
		{
			_visitor->go(this);

		}

};
class AstEmptyD : public AstNode {

	
	public : 
		vector<AstIdentifier *> statements;
		AstEmptyD(vector<AstIdentifier> *statements)
		{
			this->statements=statements;
		}
		virtual void visit(visitor* _visitor) override
		{
			_visitor->go(this);
		}
};
class AstEmptyC: public AstNode {
	public:
		vector<AstCStatement *> statements;
		AstEmptyC(vector<AstCStatement> *statements)
		{
			this->statements=statements;
		}

		virtual void visit(visitor* _visitor) override
		{
			_visitor->go(this);
		}
};
class AstCStatement : public AstNode
{
	public:
		AstCStatement()
		{
		}
		virtual void visit(visitor* _visitor) override
		{
			_visitor->go(this);
		}
};
		

};
class AstAssignment : public AstCStatement
{
	public :
		AstIdentifier *id;
		AstExp  *exp;
		AstAssignment(AstIdentifier *id,AstExp *id)
		{
			this->id=id;
			this->exp=exp;
		}

		virtual void visit(visitor* _visitor) override
		{
			_visitor->go(this);
		}
};
class AstPrinting : public CStatement
{
	public :
		vector<AstPrintVals *>  *AstPrintVals;
		string last="";
		AstPrinting(vector<AstPrintVals *> AstPrintVals)
		{
			this->AstPrintVals=AstPrintVals;
		}
		AstPrinting(vector<AstPrintVals *> AstPrintVals,string last)
		{
			this->AstPrintVals=AstPrintVals;
			this->last=last;
		}

		virtual void visit(visitor* _visitor) override
		{
			_visitor->go(this);
		}
};
class AstPrintVals : public AstNode
{
	public:
	 string txt;
	 AstExp * exp;
	AstPrintVals(string txt)
	{
		this->txt=txt;
		this->exp=NULL;
	}
	AstPrintVals(string exp)
	{
		this->exp=exp;
	}

	virtual void visit(visitor* _visitor) override
	{
		_visitor->go(this);
	}

};
class AstForLoop :public AstCStatement 
{
	public :
		AstIdentifier *id;
		AstEmptyC *emptyc;
		int start,step=-1,end;
		AstForLoop ( AstIdentifier  *id,int start,int end,AstEmptyC *emptyc)
		{
			this->id=id;
			this->start=start;
			this->end=end;
			this->emptyc=emptyc;
		}
		AstForLoop (AstIdentifer *id,int start,int step,int end)
		{
			this->id=id;
			this->start=start;
			this->step=step;
			this->end=end;
			this->emptyc=emptyc;
		}

		virtual void visit(visitor* _visitor) override
		{
			_visitor->go(this);
		}
};
class AstWhileLoop: public AstCStatement
{
	public :
			AstBoolExp *boolexp;
			AstEmptyC *emptyc;
			AstWhileLoop(AstBoolExp *boolexp,AstEmptyC *emptyc)
			{
				this->boolexp=boolexp;
				this->emptyc=emptyc;

			}

		virtual void visit(visitor* _visitor) override
		{
			_visitor->go(this);
		}
}
class AstIfElse: public AstCStatement{
	public :
		AstBoolExp *boolexp;
		AstEmptyC *then_emptyc;
		AstEmptyC *else_emptyc;
		AstIfElse(AstBoolExp *boolexp,AstEmptyC *then_emptyc,AstEmptyC*else_emptyc)
		{

			this->boolexp=boolexp;
			this->then_emptyc=then_emptyc;
			this->else_emptyc=else_emptyc;
		}

		AstIfElse(AstBoolExp *boolexp,AstEmptyC *then_emptyc)
		{
			this->boolexp=boolexp;
			this->then_emptyc=then_emptyc;
		}
		virtual void visit(visitor* _visitor) override
		{
			_visitor->go(this);
		}
		
		
};
class AstLabel:public AstCStatement{
	public:
		string id;
		AstLabel(string id)
		{
			this->id=id;
		}

		virtual void visit(visitor* _visitor) override
		{
			_visitor->go(this);
		}
};
class AstGoToo : public AstCStatement
{
	public:
		string id;
		AstBoolExp *boolexp;
		AstGoToo(string id)
		{
			this->id=id;
		}
		AstGoToo(string id,AstBoolExp *boolexp)
		{
			this->id=id;
			this->boolexp=boolexp;

		}

		virtual void visit(visitor* _visitor) override
		{
			_visitor->go(this);
		}
};
class AstReading: public AstCStatement
{
	public:
		vector<AstIdentifier *> *id;
		AstReading(AstIdentifier *id)
		{
			this->id=id;
		}

		virtual void visit(visitor* _visitor) override
		{
			_visitor->go(this);
		}
};
class AstExp : public AstNode
{
	AstExp()
	{
	}

	virtual int  visit(visitor* _visitor) override
	{
		return _visitor->go(this);
	}
};
};
class AstBinaryExp : public AstExp
{
	public:
		AstExp *left;
		AstExp *right;
		BinaryOperator op;
		AstBinaryExp(AstExp *left,AstExp *right,BinaryOperator op)
		{
			this->left=left;
			this->right=tight;
			this->op=op;
		}

		virtual int visit(visitor* _visitor) override
		{
			return _visitor->go(this);
		}
};
class AstBoolExp : public AstExp
{
	public :
		AstExp *left;
		AstExp *right;
		BooleanOperator op;
		AstBoolExp(AstExp *left,AstExp *right,BinaryOperator op)
		{
			this->left=left;
			this->right=right;
			this->op=op;
		}

		virtual int visit(visitor* _visitor) override
		{
			return _visitor->go(this);
		}
};

class AstTerm :public AstExp
{
	public : int number;
	AstIdentifier *identifier;
	AstTerm(int number)
	{
		this->number=number;
		this->identifier=NULL;
	}
	AstIdentifier(AstIdentifier *identifier)
	{
		this->identifier=identifier;
	}

	virtual int visit(visitor* _visitor) override
	{
		return _visitor->go(this);
	}
};
class AstIdentifier :public AstNode
{
	public :
		string id;
		int index;
		AstIdentifier(string id)
		{
			this->id=id;
			
		}
		AstIdentifier(string id,int index)
		{
			this->id=id;
			this->index=index;
		}
		virtual int visit(visitor* _visitor) override
		{
			return _visitor->go(this);
		}
};
class interpretVisitor  : public Visitor{
	map <ASTIdentifier,int> vT;
	map<string,ASTCStatement *> lT;
	public:
	virtual void go(AstProgram *node)
	{
		node->emptyd->visit(this);
		node->emptyc->visit(this);
	}
	virtual void go(AstEmptyD *node)
	{
		for(int i=0;i<node->statements.size();i++)
		{
			node->statements[i]->visit(this);
		}
	}
	virtual void go(AstIdentifier *node)
	{
		if(node->expr!=NULL)
		{
			if(node->index==0)
			{
				cout<<"Error\n";
			}
			for(int j=0;j<node->index;j++)
			{
				string temp=node->id +"[" + to_string(j) + "]";
				vT[*(new AstIdentifier(temp);
			}
		}
		else
		{
			vT.insert(*(node));
		}
		
	}
	virtual void go(AstEmptyC *node)
	{
		for(int i=0;i<node->statements.size();i++)
		{
			node->statements[i]->visit(this);
		}
	}
	virtual void go(AstCStatement* node)
	{
		ASTAssignment *assignment = dynamic_cast<AstAssignment *>(node);
		if(assignnment)
			assignment->visit(this);
		
		ASTReading *reading = dynamic_cast<AstReading *>(node);
		
		if(reading)
			reading->visit(this);
		ASTWhileLoop *whileloop = dynamic_cast<AstWhileLoop *>(node);
		if(whileloop)
			whileloop->visit(this);
		ASTIfElse *ifelse = dynamic_cast<AstIfElse *>(node);
		
		if(ifelse)
			ifelse->visit(this);
		ASTForLoop *forloop = dynamic_cast<AstForLoop *>(node);
		
		if(forloop)
			forloop->visit(this);
		ASTLabel *label = dynamic_cast<AstLabel *>(node);

		if(label)
			label->visit(this);
		ASTGoToo *gotoo = dynamic_cast<AstGoToo *>(node);

		if(gotoo)
			gotoo->visit(this);
		ASTPrinting *printing = dynamic_cast<Astprinting *>(node);
	}
	virtual void go(AstAssignment *node)
	{
		if(vT.find(*(node->id)!=vT.end())
		{
			vT[*(node->id)]=node->expr->visit(this);
		}
		else
		{
			cout<<"Undeclared variable used\n";
		}
	}
	virtual void go(AstReading *node)
	{
		for(int i=0;i<node->statement.size();i++)
			cin >> vT[*(node->statement[i])];
		
	}
	virtual void go(AstWhileLoop *node)
	{
		while(node->boolexp->visit(this))
		{
			node->emptyc->visit(this));
		}
	}
	virtual void go(AstIfElse *node)
	{
		if(node->boolexp->visit(this))
			node->then_emptyc->visit(this);
		else if(node->else_emptyc==NULL)
			node->else_emptyc->visit(this);
	}
	virtual void go(AstForLoop *node)
	{

		if(vT.find(*(node->id)!=vT.end())
		{
			if(node->step==-1)
			{
				int start=node->start;;
				while(start<node->end)
				{
					node->visit(node->emptyc);
					start++;
				}
			}
		}
	}
	virtual void go(AstPrinting* node)
	{
		for(int i=0;i<node->AstPrintVals.size();i++)
		{
			if(node->AstPrintVals[i]->exp==NULL)
			{
				cout<< node->AstPrintVals[i]->txt;
			}
			else
			{
				cout<<node->AstPrintVals[i]->exp->visit(this);
			}
		}
		cout<<node->last;
	}
	virtual int go(AstExp *node)
	{
		AstBoolExp *bool_exp = dynamic_cast<ASTBoolExp *>(node);
		AstBinaryExp *bool_exp = dynamic_cast<ASTBinaryExp *>(node);
		AstTerm *term = dynamic_cast<AstTerm *>(node);
		if(bool_exp!=NULL)
			return bool->exp->visit(this);
		
		if(binary_exp!=NULL)
			return binary->exp->visit(this);
		if(term!=NULL)
		{
			if(term->identifier!=NULL)
			{
				if(vT.find(*term->identifier)! =vT.end())
					return vT[*term->identifier];

			}
			else
			{
				cout<<"Error\n";
			}
		}

	}
	virtual int go(AstBinaryExp *node)
	{
		switch(node->op)
		{
			case PLUS: 
				return node->left->visit(this) + node->right->visit(this);
			break;
			case MINUS: return node->left->visit(this) + node->right->visit(this);
						break;
			case PROD :
						return node->left->visit(this) * node->right->visit(this);
						break;
			case DIV :
						return node->left->visit(this) /node->right->vist(this);
		break;
		}
	}
	virtual int go(AstBoolExp *node)
	{
		switch(bool->op)
		{

			case GT: 
				return node->left->visit(this) > node->right->visit(this);
			break;
			case LT: return node->left->visit(this) < node->right->visit(this);
						break;
			case GE :
						return node->left->visit(this) >= node->right->visit(this);
						break;
			case LE :
						return node->left->visit(this) <= node->right->vist(this);
		break;
			case NEQ: 
				return node->left->visit(this) != node->right->visit(this);
			break;
			case EQEQ :
				return node->left->visit(this)  == node->right->vist(this);
		break;


		}
	}
	virtual int go(AstTerm *node)
	{
		if(node->identifier==NULL)
			return node->number;
		else
		{
			if(vT.find(*node->identifier)!=vT.end())
			{
				return vT[*node->identifier];

			}
			else
			{
				cout<<"Error\n";
			}
		}
		
	}
};
#endif
	










